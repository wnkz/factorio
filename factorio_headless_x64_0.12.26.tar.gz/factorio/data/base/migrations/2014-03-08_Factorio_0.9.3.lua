game.player.force.reset_recipes()
